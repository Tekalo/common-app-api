export const handler = async (event, context)=>{
    for (const message of event.Records){
        await processMessageAsync(message);
    }
    console.info('done');
};
async function processMessageAsync(message) {
    try {
        console.log(`Processed message ${message.body}`);
        // Do something here
        await Promise.resolve(1);
    } catch (err) {
        console.error('There was a problem');
        throw err;
    }
}
