import { SendEmailCommand, SESClient } from '@aws-sdk/client-ses';
class SESService {
    static getSESClient() {
        return new SESClient({});
    }
    /* eslint-disable class-methods-use-this */ async sendEmail(emailBody) {
        const sesClient = SESService.getSESClient();
        const sendEmailCommand = new SendEmailCommand(emailBody);
        return sesClient.send(sendEmailCommand);
    }
}
export default SESService;
