// The aws sdk is baked into the lambda runtime and including
// the dependencies in the package.json will cause errors.
// import/no-extraneous-dependencies has been disabled below so
// the linter doesn't complain about the packages not being in dependencies
// eslint-disable-next-line import/no-extraneous-dependencies
import SESService from './SESService.js';
const SES_SERVICE = new SESService();
const SES_FROM_ADDRESS = process.env.SES_FROM_ADDRESS || 'tekalo@dev.tekalo.io';
export const generateSESInput = (message, sesFromAddress)=>{
    const friendlyFromAddress = `Tekalo <${sesFromAddress}>`;
    return {
        Destination: {
            ToAddresses: [
                message.recipientEmail
            ]
        },
        ReplyToAddresses: [
            sesFromAddress
        ],
        Message: {
            Body: {
                Html: {
                    Charset: 'UTF-8',
                    Data: message.htmlBody
                },
                Text: message.textBody === undefined ? undefined : {
                    Charset: 'UTF-8',
                    Data: message.textBody
                }
            },
            Subject: {
                Charset: 'UTF-8',
                Data: message.subject
            }
        },
        Source: friendlyFromAddress
    };
};
export const processMessage = async (message, sesService)=>{
    try {
        const emailToSend = JSON.parse(message.body);
        const parsedMessage = generateSESInput(emailToSend, SES_FROM_ADDRESS);
        return await sesService.sendEmail(parsedMessage);
    } catch (err) {
        // eslint-disable-next-line no-console
        console.error('There was a problem');
        throw err;
    }
};
export const handler = async (event)=>{
    await Promise.all(event.Records.map(async (record)=>{
        await processMessage(record, SES_SERVICE);
    }));
    // eslint-disable-next-line no-console
    console.info('done');
};
export default handler;
