// eslint-disable-next-line import/no-extraneous-dependencies
function processMessage(message) {
    try {
        console.log(`Processed message ${message.body}`);
    // Do something here
    } catch (err) {
        console.error('There was a problem');
        throw err;
    }
}
const handler = (event)=>{
    event.Records.forEach((record)=>{
        processMessage(record);
    });
    console.info('done');
};
export default handler;
