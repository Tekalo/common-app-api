// eslint-disable-next-line import/no-extraneous-dependencies
import SESService from './SESService.js';
const sesService = new SESService();
const processMessage = async (message)=>{
    try {
        // eslint-disable-next-line no-console
        console.log(`Processed message ${message.body}`);
        const parsedMessage = JSON.parse(message.body);
        return await sesService.sendEmail(parsedMessage);
    } catch (err) {
        // eslint-disable-next-line no-console
        console.error('There was a problem');
        throw err;
    }
};
const handler = async (event)=>{
    await processMessage(event.Records[0]);
    // eslint-disable-next-line no-console
    console.info('done');
};
export default handler;
