// the aws sdk is baked into the lambda runtime and including
// the dependencies in the project will cause errors
// eslint-disable-next-line import/no-extraneous-dependencies
import SESService from './SESService.js';
const sesService = new SESService();
const processMessage = async (message)=>{
    try {
        // eslint-disable-next-line no-console
        const emailToSend = JSON.parse(message.body);
        console.log(`Processed message ${emailToSend}`);
        // todo: env variable
        const sesFromAddress = 'tekalo@dev.apps.futurestech.cloud';
        const friendlyFromAddress = `Tekalo <${sesFromAddress}>`;
        const parsedMessage = {
            Destination: {
                ToAddresses: [
                    emailToSend.recipientEmail
                ]
            },
            // todo: env variable
            ReplyToAddresses: [
                sesFromAddress
            ],
            Message: {
                Body: {
                    Html: {
                        Charset: 'UTF-8',
                        Data: emailToSend.htmlBody
                    },
                    Text: emailToSend.textBody === undefined ? undefined : {
                        Charset: 'UTF-8',
                        Data: emailToSend.textBody
                    }
                },
                Subject: {
                    Charset: 'UTF-8',
                    Data: emailToSend.subject
                }
            },
            Source: friendlyFromAddress
        };
        return await sesService.sendEmail(parsedMessage);
    } catch (err) {
        // eslint-disable-next-line no-console
        console.error('There was a problem');
        throw err;
    }
};
export const handler = async (event)=>{
    await processMessage(event.Records[0]);
    // eslint-disable-next-line no-console
    console.info('done');
};
export default handler;
